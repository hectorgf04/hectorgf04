package garcia_hector_examen;

public class Objeto {

}
